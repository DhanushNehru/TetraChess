import React from 'react';
import '../styles/Board.css';
import { getPieceSymbol } from './PieceSymbol';
import type { Square } from '../engine/types';

interface BoardProps {
  board: Square[][];
  selectedSquare: [number, number] | null;
  validMoves: [number, number][];
  onSquareClick: (row: number, col: number) => void;
}

const Board: React.FC<BoardProps> = ({ board, selectedSquare, validMoves, onSquareClick }) => {
  return (
    <div className="chess-board">
      {board.map((row, r) => (
        <div key={r} className="board-row">
          {row.map((square, c) => {
            const isOutOfBounds = square === 'out-of-bounds';
            const isSelected = selectedSquare?.[0] === r && selectedSquare?.[1] === c;
            const isLegalMove = validMoves.some(m => m[0] === r && m[1] === c);
            const isDark = (r + c) % 2 === 1;

            let squareClass = 'square';
            if (isOutOfBounds) {
              squareClass += ' out-of-bounds';
            } else {
              squareClass += isDark ? ' dark' : ' light';
              if (isSelected) squareClass += ' selected';
              if (isLegalMove) squareClass += ' legal-move';
            }

            return (
              <div
                key={`${r}-${c}`}
                className={squareClass}
                onClick={() => onSquareClick(r, c)}
              >
                {!isOutOfBounds && isLegalMove && <div className="dot" />}
                {square && typeof square === 'object' && (
                  <span className={`piece ${square.color}`}>
                    {getPieceSymbol(square.color, square.type)}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
};

export default Board;
