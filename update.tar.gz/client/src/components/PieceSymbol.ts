import type { Piece } from '../engine/types';

export const getPieceSymbol = (piece: Piece): string => {
  const { type } = piece;

  // We can use standard Unicode chess characters and colour them with CSS
  switch (type) {
    case 'king': return '♚';
    case 'queen': return '♛';
    case 'rook': return '♜';
    case 'bishop': return '♝';
    case 'knight': return '♞';
    case 'pawn': return '♟';
    default: return '';
  }
};
