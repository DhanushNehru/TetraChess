import React from 'react';
import { Socket } from 'socket.io-client';
import Board from './Board';
import '../styles/Game.css';
import { createInitialBoard } from '../engine/board';
import { getLegalMoves } from '../engine/moves';
import type { Board as BoardType, Position } from '../engine/types';

interface GameProps {
  roomId: string;
  socket: Socket;
  playerName: string;
}

const Game: React.FC<GameProps> = ({ roomId, socket, playerName }) => {
  const [board, setBoard] = React.useState<BoardType>(createInitialBoard());
  const [selectedPos, setSelectedPos] = React.useState<Position | null>(null);
  const [legalMoves, setLegalMoves] = React.useState<Position[]>([]);

  React.useEffect(() => {
    socket.on('update_board', (move: { from: Position; to: Position }) => {
      setBoard(prev => {
        const newBoard = [...prev].map(row => [...row]);
        newBoard[move.to.r][move.to.c] = newBoard[move.from.r][move.from.c];
        newBoard[move.from.r][move.from.c] = null;
        return newBoard;
      });
    });

    return () => {
      socket.off('update_board');
    };
  }, [socket]);

  const handleSquareClick = (r: number, c: number) => {
    const square = board[r][c];
    if (square === 'out-of-bounds') return;

    if (selectedPos) {
      const isLegalMove = legalMoves.some(m => m.r === r && m.c === c);
      if (isLegalMove) {
        // Apply move locally
        const newBoard = [...board].map(row => [...row]);
        newBoard[r][c] = newBoard[selectedPos.r][selectedPos.c];
        newBoard[selectedPos.r][selectedPos.c] = null;
        setBoard(newBoard);

        // Broadcast to server
        socket.emit('make_move', { roomId, move: { from: selectedPos, to: { r, c } } });

        setSelectedPos(null);
        setLegalMoves([]);
      } else {
        if (square && typeof square === 'object' && 'color' in square) {
          setSelectedPos({ r, c });
          setLegalMoves(getLegalMoves(board, r, c));
        } else {
          setSelectedPos(null);
          setLegalMoves([]);
        }
      }
    } else {
      if (square !== null && typeof square === 'object' && 'color' in square) {
        setSelectedPos({ r, c });
        setLegalMoves(getLegalMoves(board, r, c));
      }
    }
  };

  return (
    <div className="game-container">
      <header className="game-header">
        <h2>TetraChess - Room: {roomId}</h2>
        <p>Player: {playerName}</p>
      </header>
      <div className="game-board">
        <Board
          board={board}
          selectedSquare={selectedPos ? [selectedPos.r, selectedPos.c] : null}
          validMoves={legalMoves.map(m => [m.r, m.c])}
          onSquareClick={handleSquareClick}
        />
      </div>
    </div>
  );
};

export default Game;
